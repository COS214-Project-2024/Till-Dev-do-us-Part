#ifndef MEMENTO_H
#define MEMENTO_H

class Memento{

};

#endif