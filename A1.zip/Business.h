#ifndef BUSINESS_H
#define BUSINESS_H

class Business{

};

#endif
