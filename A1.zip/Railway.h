// Railway.h
#pragma once
#include "TransportFacilities.h"
#include <vector>

class Railway : public TransportFacilities {

public:
    // Railway(TransState* state);
    Railway();
    ~Railway();


};