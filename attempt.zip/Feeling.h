#ifndef FEELING_H
#define FEELING_H

class Feeling{

    public:
        virtual Feeling* reaction() = 0;

};

#endif