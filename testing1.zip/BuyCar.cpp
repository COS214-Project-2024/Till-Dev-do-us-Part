#include "BuyCar.h"

BuyCar::BuyCar(Citizen* adult){
    person =  adult;
}

void BuyCar::buyCar(Transport* car){
    this->car = car;
    //balance -+ car->getPrice();
    //increaseNW (car->getPrice);
}

BuyCar::~BuyCar(){
    delete person;
    person = nullptr;

    delete car;
    car = nullptr;
}