#ifndef TRANSPORTSTRATEGY_H
#define TRANSPORTSTRATEGY_H

class TransportStrategy{

};

#endif