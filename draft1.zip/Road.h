// Road.h
#pragma once
#include "TransportFacilities.h"
#include "TransportMode.h"
#include <vector>
class TransportMode;
class Road : public TransportFacilities {

public:
    Road();
    ~Road();
 
};