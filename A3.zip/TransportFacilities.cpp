#include "TransportFacilities.h"
#include "TransportMode.h"

TransportFacilities::TransportFacilities() :moVec{}{
    // std::vector<TransportMode*> moVec;  // regular vector, no new required

}

std:: string TransportFacilities::getFacilName(){
    return name;
}

TransportFacilities:: ~TransportFacilities(){
    for (auto momo : moVec) {
        delete momo;
    }
    moVec.clear();

    citizens.clear();


}

void TransportFacilities::setState(TransState* newState) {
   if (currentState) delete currentState;
    currentState = nullptr;
    currentState = newState;
    notifyCitizens();

}
void TransportFacilities::decreaseTraffic()
{
    int elementsToDelete = 6; 
    for(int i=0; i< elementsToDelete && i < moVec.size(); i++){
        moVec.at(i)->divertingRoute(moVec.at(i)->GetFacility()->getFacilName());//come back 
    }
}

 int TransportFacilities::getModeCount()
 {
    return moVec.size();
 }

TransState* TransportFacilities:: getState()
{
    return this->currentState;
}

// void TransportFacilities::add(TransportMode* momo){
//     std:: cout<<"Cat 2"<<std::endl;
//     if(momo==NULL){
//         std:: cout<<"Cat 3"<<std::endl;
//     }
//     if(momo!=NULL){
//         //std:: cout<< "Movec: " << moVec.size()<<std:: endl;
//     moVec.push_back(momo); //
//     // TransportMode cake= *momo;
//     std:: cout<<momo->getName()<<std::endl;
//     std:: cout<<"Cat 4"<<std::endl;
//     if(currentState!=nullptr){
//         currentState->changeState();
//         std:: cout<<"Cat 5"<<std::endl;
//     }
//     }

//  }

// void TransportFacilities::add(TransportMode* momo) {
//     std::cout << "Cat 2" << std::endl;
    
//     if (momo == nullptr) {
//         std::cout << "momo is a null pointer" << std::endl;
//         return; // Exit early if momo is nullptr
//     }
//     std::cout << "Seg 1" << std::endl;
//     // Check if momo is actually pointing to a TransportMode or derived instance
//     if (dynamic_cast<TransportMode*>(momo) == nullptr) {
//         std::cout << "momo is not a valid TransportMode instance" << std::endl;
//         return;
//     }
//     std::cout << "Seg 2" << std::endl;
//     // If it's valid, continue with the logic
//     moVec.push_back(momo);
//     std::cout << "Seg 3" << std::endl;
//     std::cout << momo->getName() << std::endl;
//     std::cout << "Cat 4" << std::endl;
    
//     if (currentState) { // Ensure currentState is not nullptr
//         currentState->changeState();
//     } else {
//         std::cout << "currentState is nullptr" << std::endl;
//     }
    
//     std::cout << "Cat 5" << std::endl;
// }

void TransportFacilities::add(TransportMode* momo) {
    std::cout << "Entering add function" << std::endl;

    if (!momo) {
        std::cout << "momo is nullptr" << std::endl;
        return;
    }
    std::cout << "momo is valid" << std::endl;

    if (dynamic_cast<TransportMode*>(momo) == nullptr) {
        std::cout << "momo is not a valid TransportMode instance" << std::endl;
        return;
    }
    std::cout << "dynamic_cast successful" << std::endl;

    moVec.push_back(momo); // If this line crashes, check moVec initialization
    std::cout << "Successfully added to moVec" << std::endl;

    std::cout << momo->getName() << std::endl;
    std::cout << "Called getName on momo" << std::endl;

    if (currentState) {
        currentState->changeState();
        std::cout << "Changed state successfully" << std::endl;
    } else {
        std::cout << "currentState is nullptr" << std::endl;
    }
    
    std::cout << "Exiting add function" << std::endl;
}



void TransportFacilities::remove(TransportMode* momo){
      auto it = std::find(moVec.begin(), moVec.end(), momo);
    if (it != moVec.end()) {
        moVec.erase(it);
        currentState->changeState();  // Reevaluate state whenever a plane is removed
    }
}

int TransportFacilities::GetModeCount(){
    return moVec.size();
}

std::vector<TransportMode*> TransportFacilities::GetModes(){
    return moVec;
}

void TransportFacilities::notifyCitizens()
{
    for(auto citizen:citizens)
    {
        citizen->react();/////fix thix
    }
}
void TransportFacilities::attach(Citizen* c)
{
    citizens.push_back(c);
}
void TransportFacilities::detach(Citizen* c)
{
    citizens.erase(std::remove(citizens.begin(),citizens.end(),c),citizens.end());
}