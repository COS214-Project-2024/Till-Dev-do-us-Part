#ifndef POLICY_H
#define POLICY_H

class Policy{

};

#endif