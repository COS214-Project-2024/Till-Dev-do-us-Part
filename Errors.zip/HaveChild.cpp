// #include "HaveChild.h"

// HaveChild::HaveChild(Citizen* adult){
//     person =  adult;
// }

// void HaveChild::haveChild(Citizen* baby){
//     this->child = baby;
// }

// HaveChild::~HaveChild(){
//     delete person;
//     person = nullptr;
// }

// bool HaveChild::hasChild(){
//     return true;
// }
