#ifndef SCHOOL_H
#define SCHOOL_H

//public Building
class School{

};

#endif