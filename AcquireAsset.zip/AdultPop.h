#ifndef ADULTPOP_H
#define ADULTPOP_H

#include "Citizen.h"
#include "Adult.h"


class AdultPop{

    // public:
    //     Citizen* createPerson(){
    //         return new Adult();
    //     }
    //     Citizen** reproduce(int num){
    //         for(int i=0; i<num; i++){
                
    //         }
    //     }

};

#endif 

