#ifndef CONCRETETRANSPORT_FACTORY_H
#define CONCRETETRANSPORT_FACTORY_H

#include "TransportFactory.h"
#include "TransportMode.h"
#include "TransportStation.h"
#include <string>

class ConcreteTransportFactory : public TransportFactory {
public:
    TransportMode* createMode(const std::string& type) override;
    TransportStation* createStation(const std::string& type) override;
    TransportFacilities* createTransFacilities(const std::string& type);
};

#endif // CONCRETE_TRANSPORT_FACTORY_H