// CarMode.h
#pragma once
#include "TransportMode.h"
#include "Road.h"
#include "ModeFactory.h"


class TransportFacilities;

class CarMode : public TransportMode {
private:
    Road* road;
    TransportFacilities* facility;

public:
    CarMode();
    void operateStation() override;
    void useTransport() override;

    //Mediator
    CarMode(TransportationMediator* mediator, TransportFacilities* facility)
        : TransportMode(mediator), facility(facility) {}

    std::string getName() const override { return "CarMode"; }
    void alertAccident() override;
    void manageTraffic(const std::string& state) override;
    void set(const std::string& state) override;
    void changed(const std::string& state) override;

    TransportFacilities* getFacility() const override { return facility; }
    bool isRoadMode() const override { return true; }
    bool isRailwayMode() const override { return false; }
    bool isAirportMode() const override { return false; }
    
};