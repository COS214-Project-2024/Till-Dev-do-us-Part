#include "TaxiMode.h"

void TaxiMode::useTransport() {
    // Check if state is valid for transport
    if (state->getState() == "Congested") {
        std::cout << "Bus service delayed due to congestion" << std::endl;
        return;
    }

    // Process passenger boarding
    for (auto& passenger : passengers) {
        std::cout << "Bus boarding passenger" << std::endl;
        passenger->update("Now boarding bus");
    }

    // Update schedule and notify mediator
    notifySchedule();
    mediator->notify(this, state);
}
