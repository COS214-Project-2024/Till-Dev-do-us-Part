#ifndef TRANSPORTFACTORY_H
#define TRANSPORTFACTORY_H

#include <string>

class TransportMode; // Forward declaration
class TransportStation; // Forward declaration

class TransportFactory {
public:
    virtual TransportMode* createMode(const std::string& type) = 0;
    virtual TransportStation* createStation(const std::string& type) = 0;
    virtual ~TransportFactory() = default;
};

#endif // TRANSPORT_FACTORY_H