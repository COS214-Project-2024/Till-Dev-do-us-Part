#ifndef DEPARTMENT_H
#define DEPARTMENT_H

class Department{

    protected:
        float budget;

};


#endif