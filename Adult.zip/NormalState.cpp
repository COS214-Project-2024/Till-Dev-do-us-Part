// NormalState.cpp
#include "NormalState.h"
#include "TransportFacilities.h"
#include <iostream>

void NormalState::handleState(TransportFacilities* facility) {
    std::cout << "Operating under normal conditions." << std::endl;
    // Implement any additional logic if necessary
}
