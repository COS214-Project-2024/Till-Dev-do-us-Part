# TILL DEV DO US PART
Team-18's description.
