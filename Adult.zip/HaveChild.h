#ifndef HAVECHILD_H
#define HAVECHILD_H

#include "LifeStage.h"
#include "Transport.h"
#include "Minor.h"

class HaveChild : public LifeStage{

    private:
        Citizen* person;
        Citizen* child;

    public:
        HaveChild(Citizen*);
        void haveChild(Citizen*);
        virtual bool hasChild();
        virtual ~HaveChild();
};

#endif